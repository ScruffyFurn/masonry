# This line of code will allow shorter imports
from masonry import masonry  # noqa
